import pandas as pd
import numpy as np
import streamlit as st
import plotly.express as px
import os
import warnings
warnings.filterwarnings('ignore')
import plotly.graph_objects as go
from plotly.subplots import make_subplots

st.set_page_config(page_title="Students DB", page_icon=":bar_chart:", layout="wide")

st.title(":bar_chart: SAMPLE STUDENTS DATABASE IDEA")
st.markdown('<style>div.block-container{padding-top:2.5rem;}</style>',unsafe_allow_html=True)

fl = st.file_uploader(":file_folder: Upload a file", type=(["csv","txt","xlsx","xls"]))
if fl is not None:
    filename = fl.name
    st.write(filename)
    df = pd.read_csv(filename, encoding="ISO-8859-1")
else:
    os.chdir(r"C:\Users\Vivekanandan\Desktop\Dashboard")
    df = pd.read_csv("student_performance_large_dataset.csv", encoding="ISO-8859-1")

st.header("Data Cleaning Check")

def test_nan_with_numpy(dataframe):
    cleaned_df = dataframe.dropna()  # Drop rows with any NaNs
    try:
        assert not np.isnan(cleaned_df.values.any())  # Check for any NaNs left
        st.success("✅ Data cleaned successfully — no NaN values remain after dropna.")
    except AssertionError:
        st.error("⚠️ NaN values still exist after dropna.")
    return dataframe.isna().sum()  # Return count of NaNs per column

# Run the test and get NaN counts
nan_counts = test_nan_with_numpy(df)



weights = {
    'Exam_Score (%)': 0.50,
    'Assignment_Completion_Rate (%)': 0.30,
    'Attendance_Rate (%)': 0.20,
    'Online_Courses_Completed': 0.20
}

# --- Top 5 Students ---
st.markdown("---")
st.header("Top 5 Students: Performance Breakdown")

grouped = df.groupby('Student_ID')[['Exam_Score (%)', 'Assignment_Completion_Rate (%)', 'Attendance_Rate (%)','Online_Courses_Completed']].mean().reset_index()
grouped['Grade Distribution'] = (
    grouped['Exam_Score (%)'] * weights['Exam_Score (%)'] +
    grouped['Assignment_Completion_Rate (%)'] * weights['Assignment_Completion_Rate (%)'] +
    grouped['Attendance_Rate (%)'] * weights['Attendance_Rate (%)'] +
    grouped['Online_Courses_Completed'] * weights['Online_Courses_Completed']
)
top_5_students = grouped.sort_values('Grade Distribution', ascending=False).head(5)['Student_ID'].tolist()

fig = make_subplots(
    rows=len(top_5_students), cols=1,
    subplot_titles=[f"Student ID: {sid}" for sid in top_5_students]
)

for i, student_id in enumerate(top_5_students):
    student_data = grouped[grouped['Student_ID'] == student_id]
    categories = ['Exam Score', 'Assignment Completion', 'Attendance', 'Online Courses']
    values = student_data[['Exam_Score (%)', 'Assignment_Completion_Rate (%)', 'Attendance_Rate (%)', 'Online_Courses_Completed']].values.flatten().tolist()
    fig.add_trace(
        go.Bar(x=categories, y=values, marker_color='skyblue', showlegend=False),
        row=i+1, col=1
    )

fig.update_layout(height=350*len(top_5_students), width=800, title_text="Top 5 Students: Performance Breakdown")
st.plotly_chart(fig, use_container_width=True)

st.markdown("---")
# --- Bar Plot for Learning Styles ---
st.header("Classification of Students Based on Examination Outcomes")
def categorize_performance(df):
    if df['Final_Grade'] == 'D':
        return 'Low Performer'
    elif df['Final_Grade'] == 'B' or df['Final_Grade'] == 'C':
        return 'Medium Performer'
    else:
        return 'High Performer'

# Apply categorization
df['Performance Category'] = df.apply(categorize_performance, axis=1)

performance_counts = df['Performance Category'].value_counts().reset_index()
performance_counts.columns = ['Performance Category', 'Student Count']

fig = px.bar(
    performance_counts,
    x='Performance Category',
    y='Student Count',
    title='Student Performance Distribution',
    labels={'Performance Category': 'Performance Category', 'Student Count': 'Number of Students'},
    color='Performance Category',  
    color_continuous_scale='Viridis'
)
st.plotly_chart(fig, use_container_width=True)


st.markdown("---")

# --- Pie Charts for Learning Styles ---
st.header("Performance Distribution by Learning Style")

grouped_learning = df.groupby('Preferred_Learning_Style')[['Exam_Score (%)', 'Assignment_Completion_Rate (%)', 'Attendance_Rate (%)','Online_Courses_Completed']].mean().reset_index()
grouped_learning['Grade Distribution'] = (
    grouped_learning['Exam_Score (%)'] * weights['Exam_Score (%)'] +
    grouped_learning['Assignment_Completion_Rate (%)'] * weights['Assignment_Completion_Rate (%)'] +
    grouped_learning['Attendance_Rate (%)'] * weights['Attendance_Rate (%)'] +
    grouped_learning['Online_Courses_Completed'] * weights['Online_Courses_Completed']
)

cols = st.columns(len(grouped_learning))
for idx, index in enumerate(grouped_learning.index):
    learning_style_data = grouped_learning.loc[[index]]
    categories = ['Exam Score', 'Assignment Completion', 'Attendance', 'Online Courses']
    values = learning_style_data[['Exam_Score (%)', 'Assignment_Completion_Rate (%)', 'Attendance_Rate (%)', 'Online_Courses_Completed']].values.flatten().tolist()
    fig = go.Figure(go.Pie(labels=categories, values=values, textinfo='label+percent'))
    fig.update_layout(title_text=f"{learning_style_data['Preferred_Learning_Style'].iloc[0]}")
    with cols[idx]:
        st.plotly_chart(fig, use_container_width=True)

st.markdown("---")

# --- Bar Chart for Educational Technology ---
st.header("Average Exam Scores by Use of Educational Technology")

average_scores = df.groupby('Use_of_Educational_Tech')['Exam_Score (%)'].mean().reset_index()
fig = px.bar(
    average_scores,
    x='Use_of_Educational_Tech',
    y='Exam_Score (%)',
    title='Average Exam Scores by Use of Educational Technology',
    labels={
        'Use_of_Educational_Tech': 'Use of Educational Technology',
        'Exam_Score (%)': 'Average Exam Score (%)'
    },
    color='Use_of_Educational_Tech',  # Optional
)
fig.update_layout(
    xaxis_title='Use of Educational Technology',
    yaxis_title='Average Exam Score (%)',
    width=800,
    height=400
)
st.plotly_chart(fig, use_container_width=True)

st.markdown("---")
st.header("Download Summary Report")

import io
import pandas as pd

# Convert list to DataFrame
top_5_students_df = pd.DataFrame(top_5_students)
grouped_learning = pd.DataFrame(grouped_learning)


# Prepare Excel output
output = io.BytesIO()
with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
    top_5_students_df.to_excel(writer, sheet_name='Top 5 Students', index=False)
    grouped_learning.to_excel(writer, sheet_name='Learning Styles', index=False)
    average_scores.to_excel(writer, sheet_name='Tech Usage', index=False)
    performance_counts.to_excel(writer, sheet_name='Overall Distribution', index=False)
output.seek(0)

# Streamlit download button
st.download_button(
    label="Download Summary Report (Excel)",
    data=output,
    file_name="student_performance_report.xlsx",
    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
)

